package com.esp.simpleblog_app

data class Article(val titre: String, val auteur: String, val contenu: String, val datePublication: String)
