﻿# Android Project -- Simple Blog
 
 ## Examen Developpement Mobille
## LGSIA
 
 ## Ndèye Fatou Sène TOURE & Aissatou NIANG 
